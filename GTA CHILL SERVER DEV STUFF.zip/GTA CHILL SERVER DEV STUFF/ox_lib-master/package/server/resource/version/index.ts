export const versionCheck = (repository: string) => exports.ox_lib.versionCheck(repository);
