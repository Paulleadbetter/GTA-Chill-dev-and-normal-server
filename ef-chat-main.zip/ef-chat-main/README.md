# EF Chat

![EFCHAT](https://github.com/blastersuraj/ef-chat/assets/104319683/7a6a7afc-f692-4a72-aed2-66198fa7abab)


<h1>

Drag & Drop to your Resource folder

</h1>

<h3>
delete the chat folder from
 \resources\[cfx-default]\[gameplay]
</h3>


# Tebex

[Tebex](https://ef-development.tebex.io/)

# Discord

[Discord](https://discord.gg/ef-development-tm-936207653145833503)
